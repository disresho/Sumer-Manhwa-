package app.roshar.reader.download

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.net.URI

/**
 * Downloads a chapter into a temporary folder and publishes it only after
 * every page has completed. Data is stored in app-private storage.
 */
class ChapterDownloader(context: Context) {
    private val appContext = context.applicationContext
    private val client = OkHttpClient.Builder()
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    suspend fun downloadChapter(
        mangaId: String,
        chapterId: String,
        pageUrls: List<String>,
        headers: Map<String, String> = emptyMap(),
        onProgress: (done: Int, total: Int) -> Unit = { _, _ -> }
    ): File = withContext(Dispatchers.IO) {
        require(pageUrls.isNotEmpty()) { "Chapter has no pages" }
        val safeManga = safeSegment(mangaId)
        val safeChapter = safeSegment(chapterId)
        val parent = File(appContext.filesDir, "offline/$safeManga")
        if (!parent.exists() && !parent.mkdirs()) throw IOException("Could not create download directory")

        val target = File(parent, safeChapter)
        val staging = File(parent, ".$safeChapter.downloading")
        staging.deleteRecursively()
        if (!staging.mkdirs()) throw IOException("Could not create temporary chapter directory")

        try {
            pageUrls.forEachIndexed { index, url ->
                require(isHttps(url)) { "Only HTTPS page URLs are accepted" }
                val builder = Request.Builder().url(url)
                headers.forEach { (key, value) ->
                    if (key.isNotBlank() && value.isNotBlank()) builder.header(key, value)
                }
                client.newCall(builder.build()).execute().use { response ->
                    if (!response.isSuccessful) throw IOException("Page ${index + 1}: HTTP ${response.code}")
                    val body = response.body ?: throw IOException("Empty page ${index + 1}")
                    val contentType = body.contentType()?.toString().orEmpty()
                    if (contentType.isNotBlank() && !contentType.startsWith("image/")) {
                        throw IOException("Page ${index + 1} is not an image")
                    }
                    val output = File(staging, "page_${index + 1}.jpg")
                    output.outputStream().buffered().use { body.byteStream().copyTo(it) }
                    if (output.length() == 0L) throw IOException("Empty image on page ${index + 1}")
                }
                onProgress(index + 1, pageUrls.size)
            }

            File(staging, "chapter.info").writeText(
                "mangaId=$safeManga\nchapterId=$safeChapter\npages=${pageUrls.size}\n"
            )
            target.deleteRecursively()
            if (!staging.renameTo(target)) throw IOException("Could not finalize downloaded chapter")
            target
        } catch (error: Throwable) {
            staging.deleteRecursively()
            throw error
        }
    }

    suspend fun deleteChapter(mangaId: String, chapterId: String) = withContext(Dispatchers.IO) {
        val safeManga = safeSegment(mangaId)
        val safeChapter = safeSegment(chapterId)
        File(appContext.filesDir, "offline/$safeManga/$safeChapter").deleteRecursively()
    }

    fun getOfflinePages(mangaId: String, chapterId: String): List<File> {
        val safeManga = safeSegment(mangaId)
        val safeChapter = safeSegment(chapterId)
        return File(appContext.filesDir, "offline/$safeManga/$safeChapter")
            .listFiles { file -> file.name.matches(Regex("page_\\d+\\.jpg")) }
            ?.sortedBy { it.name.substringAfter("page_").substringBefore(".").toIntOrNull() ?: 0 }
            ?: emptyList()
    }

    private fun safeSegment(value: String): String =
        value.replace(Regex("[^a-zA-Z0-9_-]"), "_").ifBlank { "item" }

    private fun isHttps(value: String): Boolean = runCatching {
        val uri = URI(value)
        uri.scheme.equals("https", ignoreCase = true) && !uri.host.isNullOrBlank()
    }.getOrDefault(false)
}
