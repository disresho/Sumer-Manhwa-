package app.roshar.reader.offline

import android.content.Context
import java.io.File

data class OfflineChapter(
    val mangaId: String,
    val chapterId: String,
    val folder: File,
    val pages: List<File>
) {
    val title: String get() = chapterId.replace('_', ' ')
}

object OfflineLibrary {
    fun chapters(context: Context): List<OfflineChapter> {
        val root = File(context.filesDir, "offline")
        return root.listFiles()?.filter { it.isDirectory }?.flatMap { manga ->
            manga.listFiles()?.filter { it.isDirectory }?.mapNotNull { chapter ->
                val pages = chapter.listFiles { f ->
                    f.isFile && f.name.matches(Regex("page_\\d+\\.jpg"))
                }?.sortedBy {
                    it.name.substringAfter("page_").substringBefore(".").toIntOrNull() ?: 0
                } ?: emptyList()
                if (pages.isEmpty()) null
                else OfflineChapter(manga.name, chapter.name, chapter, pages)
            } ?: emptyList()
        }?.sortedBy { it.mangaId + it.chapterId } ?: emptyList()
    }

    fun delete(chapter: OfflineChapter): Boolean = chapter.folder.deleteRecursively()

    fun progressKey(chapter: OfflineChapter) = "progress_${chapter.mangaId}_${chapter.chapterId}"
}
