package app.roshar.reader.source

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.URI

data class InstalledSource(
    val name: String,
    val url: String,
    val language: String = "unknown",
    val sourceType: String = "manifest"
)

data class SourceImportResult(val success: Boolean, val message: String)

object InstalledSources {
    private const val PREFS = "sumermanhwa_sources"
    private const val KEY = "items"
    private const val REPOSITORIES_KEY = "repositories"

    fun all(context: Context): List<InstalledSource> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            (0 until array.length()).mapNotNull { i ->
                val item = array.optJSONObject(i) ?: return@mapNotNull null
                InstalledSource(
                    name = item.optString("name"),
                    url = item.optString("url"),
                    language = item.optString("language", "unknown"),
                    sourceType = item.optString("sourceType", "manifest")
                )
            }
        }.getOrDefault(emptyList())
    }

    fun add(context: Context, name: String, url: String): Boolean {
        if (!isSafeHttpsUrl(url)) return false
        if (all(context).any { it.url.equals(url, ignoreCase = true) }) return false
        save(context, all(context) + InstalledSource(name.ifBlank { url }, url, sourceType = "link"))
        return true
    }

    fun importManifest(context: Context, jsonText: String): SourceImportResult {
        return try {
            val obj = JSONObject(jsonText)
            val id = obj.optString("id").trim()
            val name = obj.optString("name").trim()
            val baseUrl = obj.optString("baseUrl").trim()
            val language = obj.optString("language", "unknown").trim()
            val version = obj.optInt("version", 1)

            if (id.isBlank() || name.isBlank() || !isSafeHttpsUrl(baseUrl)) {
                return SourceImportResult(false, "ملف المصدر ناقص أو يحتوي بيانات غير صالحة.")
            }
            if (version != 1) return SourceImportResult(false, "إصدار ملف المصدر غير مدعوم.")
            if (all(context).any { it.url.equals(baseUrl, ignoreCase = true) }) {
                return SourceImportResult(false, "هذا المصدر مضاف مسبقاً.")
            }

            // Validate the declared adapter type and selector object before storing.
            val adapter = obj.optString("adapter", "html")
            if (adapter !in setOf("html", "api")) {
                return SourceImportResult(false, "نوع موصل المصدر غير مدعوم.")
            }
            if (adapter == "html" && !obj.has("selectors")) {
                return SourceImportResult(false, "ملف HTML يحتاج قسم selectors.")
            }
            save(context, all(context) + InstalledSource(name, baseUrl, language, adapter))
            SourceImportResult(
                true,
                "تم استيراد إعدادات المصدر. تشغيله يحتاج محرك موصل متوافقاً؛ الاستيراد وحده لا يضمن دعم الموقع."
            )
        } catch (_: Exception) {
            SourceImportResult(false, "تعذر قراءة JSON. تأكد أن الملف صحيح.")
        }
    }

    fun addRepository(context: Context, repositoryUrl: String): SourceImportResult {
        if (!isSafeHttpsUrl(repositoryUrl)) {
            return SourceImportResult(false, "رابط المستودع يجب أن يبدأ بـ HTTPS.")
        }
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val current = runCatching { JSONArray(prefs.getString(REPOSITORIES_KEY, "[]")) }
            .getOrDefault(JSONArray())
        for (i in 0 until current.length()) {
            if (current.optString(i).equals(repositoryUrl, ignoreCase = true)) {
                return SourceImportResult(false, "المستودع مضاف مسبقاً.")
            }
        }
        current.put(repositoryUrl)
        prefs.edit().putString(REPOSITORIES_KEY, current.toString()).apply()
        return SourceImportResult(
            true,
            "تم حفظ رابط المستودع. جلب فهرسه وتثبيت مصادره يحتاجان إلى موصل المستودعات."
        )
    }

    fun remove(context: Context, url: String) {
        save(context, all(context).filterNot { it.url == url })
    }

    private fun save(context: Context, sources: List<InstalledSource>) {
        val array = JSONArray()
        sources.forEach { source ->
            array.put(
                JSONObject()
                    .put("name", source.name)
                    .put("url", source.url)
                    .put("language", source.language)
                    .put("sourceType", source.sourceType)
            )
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, array.toString()).apply()
    }

    private fun isSafeHttpsUrl(value: String): Boolean = runCatching {
        val uri = URI(value)
        uri.scheme.equals("https", ignoreCase = true) && !uri.host.isNullOrBlank()
    }.getOrDefault(false)
}
