package app.roshar.reader

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import app.roshar.reader.source.MadaraSource
import app.roshar.reader.source.MangaItem
import app.roshar.reader.source.ChapterItem
import androidx.compose.ui.platform.LocalLayoutDirection
import coil.compose.AsyncImage
import java.io.File
import java.io.BufferedReader
import java.io.InputStreamReader
import app.roshar.reader.offline.OfflineChapter
import app.roshar.reader.offline.OfflineLibrary
import app.roshar.reader.source.InstalledSources

private val Ink = Color(0xFF171321)
private val Violet = Color(0xFF9B6DFF)
private val Muted = Color(0xFFB7AFC6)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RosharApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RosharApp() {
    var selected by remember { mutableStateOf(0) }
    var openedChapter by remember { mutableStateOf<OfflineChapter?>(null) }
    val tabs = listOf("مكتبتي", "اكتشف", "التنزيلات", "المصادر")
    BackHandler(enabled = openedChapter != null) { openedChapter = null }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = darkColorScheme(
                primary = Violet,
                background = Ink,
                surface = Color(0xFF211B2D),
                onBackground = Color.White,
                onSurface = Color.White
            )
        ) {
            if (openedChapter != null) {
                OfflineReader(chapter = openedChapter!!, onBack = { openedChapter = null })
            } else {
                Scaffold(
                    containerColor = Ink,
                    topBar = {
                        CenterAlignedTopAppBar(
                            title = {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Sumer Manhwa", fontWeight = FontWeight.Black)
                                    Text("قارئ المانغا والمانهوا", style = MaterialTheme.typography.labelSmall, color = Muted)
                                }
                            },
                            colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                                containerColor = Ink,
                                titleContentColor = Color.White
                            )
                        )
                    },
                    bottomBar = {
                        NavigationBar(containerColor = Color(0xFF211B2D)) {
                            val icons = listOf(Icons.Default.Bookmarks, Icons.Default.Explore, Icons.Default.Download, Icons.Default.Extension)
                            tabs.forEachIndexed { index, label ->
                                NavigationBarItem(
                                    selected = selected == index,
                                    onClick = { selected = index },
                                    icon = { Icon(icons[index], contentDescription = label) },
                                    label = { Text(label) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Violet,
                                        indicatorColor = Color(0xFF38294F),
                                        selectedTextColor = Violet,
                                        unselectedTextColor = Muted
                                    )
                                )
                            }
                        }
                    }
                ) { padding ->
                    Box(Modifier.padding(padding).fillMaxSize()) {
                        when (selected) {
                            0 -> LibraryScreen()
                            1 -> DiscoverScreen()
                            2 -> DownloadsScreen(onOpen = { openedChapter = it })
                            else -> SourcesScreen()
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LibraryScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("مكتبتي", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("الأعمال التي تضيفها ستظهر هنا.", color = Muted)
        Spacer(Modifier.height(24.dp))
        EmptyPanel("مكتبتك فارغة حالياً", "بعد ربط مصدر متوافق وإضافة عمل، سيظهر هنا.")
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiscoverScreen() {
    val source = remember { MadaraSource("https://mangalik.net") }
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<MangaItem>>(emptyList()) }
    var chapters by remember { mutableStateOf<List<ChapterItem>>(emptyList()) }
    var pageUrls by remember { mutableStateOf<List<String>>(emptyList()) }
    var selectedManga by remember { mutableStateOf<MangaItem?>(null) }
    var selectedChapter by remember { mutableStateOf<ChapterItem?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    if (selectedChapter != null && pageUrls.isNotEmpty()) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { selectedChapter = null; pageUrls = emptyList() }) {
                    Icon(Icons.Default.ArrowBack, "رجوع")
                }
                Text(selectedChapter!!.title, fontWeight = FontWeight.Bold, maxLines = 1)
            }
            LazyColumn(Modifier.fillMaxSize()) {
                items(pageUrls) { url ->
                    AsyncImage(
                        model = url,
                        contentDescription = "صفحة من الفصل",
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
        return
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("اكتشف", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text("MangaLik", color = Violet, style = MaterialTheme.typography.labelLarge)
        }
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("ابحث عن مانهوا...") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            singleLine = true
        )
        Button(
            onClick = {
                if (query.isNotBlank()) scope.launch {
                    loading = true; error = null; selectedManga = null; chapters = emptyList()
                    runCatching { source.search(query.trim()) }
                        .onSuccess { results = it; if (it.isEmpty()) error = "لم يتم العثور على نتائج." }
                        .onFailure { error = "تعذر الاتصال بالمصدر: ${it.message}" }
                    loading = false
                }
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = !loading && query.isNotBlank()
        ) { Text(if (loading) "جارٍ البحث..." else "بحث") }

        error?.let { Text(it, color = Color(0xFFFF9B9B), modifier = Modifier.padding(vertical = 8.dp)) }

        if (selectedManga != null) {
            val manga = selectedManga!!
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { selectedManga = null; chapters = emptyList() }) {
                    Icon(Icons.Default.ArrowBack, "رجوع")
                }
                Column {
                    Text(manga.title, fontWeight = FontWeight.Bold)
                    Text("الفصول", color = Muted, style = MaterialTheme.typography.labelSmall)
                }
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(chapters) { chapter ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable {
                            scope.launch {
                                loading = true; error = null
                                runCatching { source.getPageUrls(chapter.url) }
                                    .onSuccess {
                                        pageUrls = it
                                        selectedChapter = if (it.isNotEmpty()) chapter else null
                                        if (it.isEmpty()) error = "لم يتم العثور على صور لهذا الفصل."
                                    }
                                    .onFailure { error = "تعذر فتح الفصل: ${it.message}" }
                                loading = false
                            }
                        },
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF211B2D))
                    ) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.MenuBook, null, tint = Violet)
                            Spacer(Modifier.width(10.dp))
                            Text(chapter.title, modifier = Modifier.weight(1f))
                            Icon(Icons.Default.ChevronLeft, null)
                        }
                    }
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(results, key = { it.url }) { manga ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable {
                            selectedManga = manga
                            scope.launch {
                                loading = true; error = null
                                runCatching { source.getChapters(manga.url) }
                                    .onSuccess { chapters = it; if (it.isEmpty()) error = "لم يتم العثور على فصول لهذا العمل." }
                                    .onFailure { error = "تعذر جلب الفصول: ${it.message}" }
                                loading = false
                            }
                        },
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF211B2D))
                    ) {
                        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            manga.coverUrl?.let {
                                AsyncImage(model = it, contentDescription = null, modifier = Modifier.size(76.dp, 100.dp))
                            }
                            Spacer(Modifier.width(12.dp))
                            Text(manga.title, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Icon(Icons.Default.ChevronLeft, null, tint = Violet)
                        }
                    }
                }
            }
        }
        if (loading) {
            LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
        }
    }
}

@Composable
fun DownloadsScreen(onOpen: (OfflineChapter) -> Unit) {
    val context = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    val chapters = remember(refresh) { OfflineLibrary.chapters(context) }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("التنزيلات", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { refresh++ }) { Icon(Icons.Default.Refresh, "تحديث") }
        }
        Text("الفصول المحفوظة على الهاتف للقراءة دون إنترنت.", color = Muted)
        Spacer(Modifier.height(12.dp))
        if (chapters.isEmpty()) {
            EmptyPanel("لا توجد فصول محمّلة", "عند تنزيل فصل متوافق سيظهر هنا ويمكن فتحه دون إنترنت.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(chapters, key = { it.folder.absolutePath }) { chapter ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { onOpen(chapter) },
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF211B2D))
                    ) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.MenuBook, null, tint = Violet)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(chapter.mangaId.replace('_', ' '), fontWeight = FontWeight.Bold)
                                Text(chapter.title, color = Muted, style = MaterialTheme.typography.bodySmall)
                            }
                            Text("${chapter.pages.size} صفحة", color = Muted)
                            IconButton(onClick = {
                                OfflineLibrary.delete(chapter)
                                refresh++
                            }) { Icon(Icons.Default.Delete, "حذف", tint = Color(0xFFFF8A8A)) }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OfflineReader(chapter: OfflineChapter, onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("sumermanhwa_reading", 0) }
    val key = remember(chapter) { OfflineLibrary.progressKey(chapter) }
    val startPage = remember(chapter) { prefs.getInt(key, 0).coerceIn(0, chapter.pages.lastIndex.coerceAtLeast(0)) }
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = startPage)
    LaunchedEffect(listState, key) {
        snapshotFlow { listState.firstVisibleItemIndex }.collect { index ->
            prefs.edit().putInt(key, index).apply()
        }
    }
    Scaffold(
        containerColor = Color.Black,
        topBar = {
            TopAppBar(
                title = { Text(chapter.title, maxLines = 1) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "رجوع") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink, titleContentColor = Color.White, navigationIconContentColor = Color.White)
            )
        }
    ) { padding ->
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize().padding(padding),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            items(chapter.pages, key = { it.name }) { page ->
                AsyncImage(
                    model = page,
                    contentDescription = "صفحة من الفصل",
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
fun SourcesScreen() {
    val context = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    var showDialog by remember { mutableStateOf(false) }
    var showRepositoryDialog by remember { mutableStateOf(false) }
    var sourceName by remember { mutableStateOf("") }
    var sourceUrl by remember { mutableStateOf("") }
    var repositoryUrl by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    val sources = remember(refresh) { InstalledSources.all(context) }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val result = runCatching {
                context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    ?: throw IllegalStateException("تعذر فتح الملف")
            }.fold(
                onSuccess = { InstalledSources.importManifest(context, it) },
                onFailure = { app.roshar.reader.source.SourceImportResult(false, "تعذر قراءة الملف المحدد.") }
            )
            message = result.message
            if (result.success) refresh++
        }
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("إضافة رابط مصدر") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(sourceName, { sourceName = it }, label = { Text("اسم المصدر") }, singleLine = true)
                    OutlinedTextField(sourceUrl, { sourceUrl = it }, label = { Text("رابط HTTPS") }, singleLine = true)
                    Text("حفظ الرابط لا يجعله مصدراً قابلاً للقراءة تلقائياً؛ يلزم موصل متوافق.", color = Muted, style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val ok = InstalledSources.add(context, sourceName.trim(), sourceUrl.trim())
                    message = if (ok) "تم حفظ الرابط. يحتاج إلى موصل متوافق للتشغيل." else "الرابط غير صالح أو مضاف مسبقاً. استخدم HTTPS."
                    if (ok) { sourceName = ""; sourceUrl = ""; showDialog = false; refresh++ }
                }) { Text("حفظ") }
            },
            dismissButton = { TextButton(onClick = { showDialog = false }) { Text("إلغاء") } }
        )
    }

    if (showRepositoryDialog) {
        AlertDialog(
            onDismissRequest = { showRepositoryDialog = false },
            title = { Text("إضافة مستودع مصادر") },
            text = {
                OutlinedTextField(
                    repositoryUrl,
                    { repositoryUrl = it },
                    label = { Text("رابط فهرس المستودع HTTPS") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val result = InstalledSources.addRepository(context, repositoryUrl.trim())
                    message = result.message
                    if (result.success) { repositoryUrl = ""; showRepositoryDialog = false; refresh++ }
                }) { Text("حفظ") }
            },
            dismissButton = { TextButton(onClick = { showRepositoryDialog = false }) { Text("إلغاء") } }
        )
    }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("المصادر", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("أضف إعدادات مصادر متوافقة أو احفظ روابطها.", color = Muted)
        Spacer(Modifier.height(14.dp))
        Button(onClick = { showDialog = true }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.AddLink, null)
            Spacer(Modifier.width(8.dp))
            Text("إضافة رابط مصدر")
        }
        OutlinedButton(
            onClick = { importLauncher.launch(arrayOf("application/json", "text/*")) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.FileOpen, null)
            Spacer(Modifier.width(8.dp))
            Text("استيراد ملف مصدر JSON من الهاتف")
        }
        OutlinedButton(onClick = { showRepositoryDialog = true }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Inventory2, null)
            Spacer(Modifier.width(8.dp))
            Text("إضافة مستودع مصادر")
        }
        message?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = Violet, style = MaterialTheme.typography.bodySmall)
        }
        Spacer(Modifier.height(12.dp))
        if (sources.isEmpty()) EmptyPanel("لا توجد مصادر مضافة", "أضف رابطاً أو استورد ملف إعدادات JSON.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(sources, key = { it.url }) { source ->
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF211B2D))) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(source.name, fontWeight = FontWeight.Bold)
                            Text("${source.language} • ${source.sourceType}", color = Muted, style = MaterialTheme.typography.labelSmall)
                            Text(source.url, color = Muted, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                        }
                        IconButton(onClick = { InstalledSources.remove(context, source.url); refresh++ }) {
                            Icon(Icons.Default.Delete, "حذف", tint = Color(0xFFFF8A8A))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyPanel(title: String, subtitle: String) {
    Surface(color = Color(0xFF211B2D), shape = MaterialTheme.shapes.large, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.AutoStories, null, tint = Violet, modifier = Modifier.size(38.dp))
            Spacer(Modifier.height(10.dp))
            Text(title, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Text(subtitle, color = Muted, style = MaterialTheme.typography.bodySmall)
        }
    }
}
