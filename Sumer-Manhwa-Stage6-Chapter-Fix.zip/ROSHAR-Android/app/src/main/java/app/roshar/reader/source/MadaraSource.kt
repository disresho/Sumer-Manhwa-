package app.roshar.reader.source

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import java.net.URLEncoder
import java.net.URI
import java.util.concurrent.TimeUnit

class MadaraSource(
    baseUrl: String,
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true).build()
) : MangaSource {
    private val base = baseUrl.trimEnd('/')
    override val id = "madara-" + base.hashCode().toUInt().toString(16)
    override val name = "MangaLik"
    override val language = "ar"

    private suspend fun document(url: String) = withContext(Dispatchers.IO) {
        val request = Request.Builder().url(url)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/122 Mobile Safari/537.36")
            .header("Accept", "text/html,application/xhtml+xml").build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IllegalStateException("HTTP ${response.code}")
            Jsoup.parse(response.body?.string().orEmpty(), response.request.url.toString())
        }
    }

    override suspend fun search(query: String): List<MangaItem> {
        val q = URLEncoder.encode(query, "UTF-8")
        val doc = document("$base/?s=$q&post_type=wp-manga")
        return doc.select(".c-tabs-item__content, .row.c-tabs-item__content, .manga, .page-item-detail, .bs")
            .mapNotNull { card ->
                val link = card.selectFirst("a[href]") ?: return@mapNotNull null
                val title = card.selectFirst(".post-title, .h5, .tt, .manga-title")?.text()?.takeIf { it.isNotBlank() }
                    ?: link.attr("title").ifBlank { link.text() }
                if (title.isBlank()) return@mapNotNull null
                val img = card.selectFirst("img")
                MangaItem(title.trim(), link.absUrl("href"), img?.let {
                    it.absUrl("data-src").ifBlank { it.absUrl("src") }
                })
            }.distinctBy { it.url }
    }

    override suspend fun getDetails(mangaUrl: String): MangaDetails {
        val doc = document(mangaUrl)
        val title = doc.selectFirst(".post-title h1, .post-title h2, h1")?.text()?.trim().orEmpty()
        val description = doc.selectFirst(".summary__content, .description-summary, .manga-excerpt")?.text()?.trim()
        val image = doc.selectFirst(".summary_image img, .manga-thumb img, .summary_image a img")
        val genres = doc.select(".genres-content a, .manga-genres a").map { it.text().trim() }.filter { it.isNotBlank() }
        return MangaDetails(title.ifBlank { doc.title() }, description, image?.let {
            it.absUrl("data-src").ifBlank { it.absUrl("src") }
        }, genres)
    }

    override suspend fun getChapters(mangaUrl: String): List<ChapterItem> {
        val doc = document(mangaUrl)
        val fromKnownSelectors = doc.select(
            ".wp-manga-chapter a, .listing-chapters_wrap a, .chapter a, .chapters-list a"
        ).mapNotNull { a ->
            val href = a.absUrl("href")
            val title = a.text().trim()
            if (href.isBlank() || title.isBlank()) null else ChapterItem(title, href, chapterNumber(title))
        }

        // MangaLik pages may render chapter links outside the standard Madara containers.
        // Fallback: accept chapter-like child URLs under the manga's own URL path.
        val basePath = runCatching { URI(mangaUrl).path.trimEnd('/') }.getOrDefault("")
        val fallback = doc.select("a[href]").mapNotNull { a ->
            val href = a.absUrl("href")
            val path = runCatching { URI(href).path.trimEnd('/') }.getOrNull() ?: return@mapNotNull null
            if (basePath.isBlank() || !path.startsWith("$basePath/")) return@mapNotNull null
            val relative = path.removePrefix("$basePath/").trim('/')
            val parts = relative.split('/').filter { it.isNotBlank() }
            if (parts.isEmpty() || parts.size > 2) return@mapNotNull null
            val candidate = parts.last()
            if (!candidate.matches(Regex("(?i)(?:chapter[-_ ]*)?\\d+(?:[._-]\\d+)?"))) return@mapNotNull null
            val title = a.text().trim().ifBlank { candidate.replace('-', ' ') }
            if (title.isBlank()) null else ChapterItem(title, href, chapterNumber(title) ?: chapterNumber(candidate))
        }

        return (fromKnownSelectors + fallback)
            .distinctBy { it.url }
            .sortedWith(compareByDescending<ChapterItem> { it.number ?: -1f })
    }

    private fun chapterNumber(value: String): Float? =
        Regex("(?i)(?:chapter\\s*)?(\\d+(?:\\.\\d+)?)")
            .find(value)?.groupValues?.getOrNull(1)?.toFloatOrNull()

    override suspend fun getPageUrls(chapterUrl: String): List<String> {
        val doc = document(chapterUrl)
        val images = doc.select(
            ".reading-content img, .page-break img, .chapter-content img, " +
                "#readerarea img, .reading-area img, .wp-manga-chapter-img, .entry-content img"
        )
        return images.mapNotNull { img ->
            val source = listOf("data-src", "data-lazy-src", "data-original", "data-cfsrc", "src")
                .firstNotNullOfOrNull { key ->
                    img.attr(key).takeIf { it.isNotBlank() && !it.startsWith("data:") }?.let { key to it }
                } ?: return@mapNotNull null
            val (attribute, raw) = source
            val url = img.absUrl(attribute)
                .ifBlank { runCatching { URI(chapterUrl).resolve(raw).toString() }.getOrDefault("") }
            url.takeIf { it.startsWith("https://") || it.startsWith("http://") }
        }.distinct()
    }
}
