package app.roshar.reader.source

interface MangaSource {
    val id: String
    val name: String
    val language: String
    suspend fun search(query: String): List<MangaItem>
    suspend fun getDetails(mangaUrl: String): MangaDetails
    suspend fun getChapters(mangaUrl: String): List<ChapterItem>
    suspend fun getPageUrls(chapterUrl: String): List<String>
}
data class MangaItem(val title: String, val url: String, val coverUrl: String? = null, val description: String? = null)
data class MangaDetails(val title: String, val description: String?, val coverUrl: String?, val genres: List<String> = emptyList())
data class ChapterItem(val title: String, val url: String, val number: Float? = null)
